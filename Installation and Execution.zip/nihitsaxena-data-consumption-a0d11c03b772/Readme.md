# Azure Purview - Data Consumption Series

Learning Azure Purview services in Azure Cloud, Scanned the data from SQL databases into azure purview and performed the operations in Azure Purview.


## Code Description


    There are no codes associated with this project.  Everything is via UI based.

